from django.urls import path, include

from . import views

urlpatterns = [
    path('', views.home_view, name='home'),
    path('index/', views.index_view, name='index'),
    path('index2/', views.index2_view, name='index2'),
    path('index3/', views.index3_view, name='index3'),
    path('index2/marketing/', views.marketing_view, name='marketing'),
    path('index2/design/', views.design_view, name='design'),
    path('index2/stock/', views.stock_view, name='stock'),
    path('index2/production/', views.production_view, name='production'),
    path('index2/customandfinance/', views.customandfinance_view, name='customandfinance'),
    path('download/<int:id>', views.download, name='download'),


]