from django.shortcuts import render, redirect
from django.template import loader
from django.http import HttpResponse, HttpResponseRedirect
from django.views.static import serve
import os
from .models import Report
from django.db.models import F
from django.contrib.auth.decorators import login_required
 

# Create your views here.

@login_required
def home_view(request):
    return render(request, 'home.html')


@login_required
def index_view(request):
    reports = Report.objects.filter(category="POWERBI")
    return render(request, "index.html", {'reports': reports})

@login_required
def index3_view(request):
    reports = Report.objects.filter(category="CHRONOS")
    return render(request, "index3.html", {'reports': reports})


@login_required
def index2_view(request):
    reports = Report.objects.filter(category="SAP")
    return render(request, "index2.html", {'reports': reports})


@login_required
def marketing_view(request):
    reports = Report.objects.filter(category="SAP").filter(department="marketing")
    return render(request, "marketing.html", {'reports': reports})


@login_required
def production_view(request):
    reports = Report.objects.filter(category="SAP").filter(department="production")
    return render(request, "production.html", {'reports': reports})


@login_required
def design_view(request):
    reports = Report.objects.filter(category="SAP").filter(department="design")
    return render(request, "design.html", {'reports': reports})


@login_required
def stock_view(request):
    reports = Report.objects.filter(category="SAP").filter(department="stock")
    return render(request, "stock.html", {'reports': reports})


@login_required
def customandfinance_view(request):
    reports = Report.objects.filter(category="SAP").filter(department="customandfinance")
    return render(request, "customandfinance.html", {'reports': reports})


@login_required
def download(request, id):
    report = Report.objects.get(id=id)
    Report.objects.filter(pk=id).update(count=F('count') + 1)
    if "http" not in report.link:
        file = os.path.basename(report.link)
        with open(report.link, 'rb') as xlsx:
            response = HttpResponse(xlsx.read())
            response['content_type'] = 'application/xlsx'
            response['Content-Disposition'] = 'attachment;filename=' + file
        return response
    else:
        return redirect(report.link)


#    return report.link    HttpResponseRedirect(report.link)


