from django.db import models


# Create your models here.
class Report(models.Model):
    name = models.CharField(max_length=100)
    description = models.CharField(max_length=200)
    category = models.CharField(max_length=50)
    department = models.CharField(max_length=30)
    link = models.CharField(max_length=200)
    count = models.IntegerField()

    class Meta:
        db_table = "report_table"
