from django.shortcuts import render, redirect
from django.views.generic.list import ListView
from .models import Post
from django.conf import settings
from django.http import HttpResponse, Http404
from django.contrib import messages
from django.contrib.auth.models import User
import os
import mimetypes
from django.core.files.storage import FileSystemStorage
from .forms import PostForm


# Create your views here.
class HomePageView(ListView):
    model = Post

    def get(self, request):
        user = request.user
        all_posts = self.model.objects.filter(receiver=user).order_by('-id')
        param = {'posts': all_posts}
        return render(request, 'msgbox/home.html', param)


# Create Upload File System
class UploadView(ListView):
    def get(self, request):
        return render(request, 'msgbox/upload_file.html')

    def post(self, request):
        if request.method == "POST":
            uploaded_file = request.FILES['filename']
            title = request.POST['title']
            desc = request.POST['desc']
            send_to = request.POST['send_to']
            fs = FileSystemStorage()
            fs.save(uploaded_file.name, uploaded_file)
            user_obj = request.user
            upload_post = Post(user=user_obj, title=title, file_field=uploaded_file, desc=desc, receiver=send_to)
            upload_post.save()
            messages.success(request, 'Your Post has been sent successfully.')
            return render(request, 'msgbox/upload_file.html')
        else:
            return render(request, 'msgbox/upload_file.html')


def upload_files(request):
    if request.method == 'POST':
        form = PostForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            return redirect('profile')
        else:
            form = PostForm()
            messages.success(request, 'Your Post has been not sent successfully.')
    return render(request, 'msgbox/upload_file.html', {'form': form})


# View User Profile
class ProfileView(ListView):
    def get(self, request, user_name):
        user_obj = User.objects.get(username=user_name)
        user_posts = user_obj.post_set.all().order_by('-id')
        param = {'user_data': user_obj, 'user_posts': user_posts}
        return render(request, 'msgbox/profile.html', param)


# Post Delete View

class DeleteView(ListView):
    model = Post

    def get(self, request, post_id):
        user = request.session['user']
        delete_post = self.model.objects.get(id=post_id)
        delete_post.delete()
        messages.success(request, 'Your post has been deleted successfully.')
        return redirect(f'/profile/{user}')


# Search View
class SearchView(ListView):
    def get(self, request):
        query = request.GET['query']
        search_users = User.objects.filter(username__icontains=query)
        search_title = Post.objects.filter(title__icontains=query)
        search_desc = Post.objects.filter(desc__icontains=query)
        search_result = search_title.union(search_desc)
        param = {'query': query, 'search_result': search_result, 'search_users': search_users}
        return render(request, 'msgbox/search.html', param)

# Login System
# class LoginView(ListView):
#     def get(self, request):
#         return redirect('home')
#
#     def post(self, request):
#         user_name = request.POST['uname']
#         pwd = request.POST['pwd']
#
#         user_exists = User.objects.filter(username=user_name, password=pwd).exists()
#         if user_exists:
#             request.session['user'] = user_name
#             messages.success(request, 'You are logged in successfully.')
#             return redirect('home')
#         else:
#             messages.warning(request, 'Invalid Username or Password.')
#             return redirect('home')
#         return redirect('home')


# class LogoutView(ListView):
#     def get(self, request):
#         try:
#             del request.session['user']
#         except:
#             return redirect('home')
#         return redirect('home')

# def download_file(request, id):
#     # fill these variables with real values
#     post = Post.objects.get(id=id)
#     path = post.file_field.url
#     fl_path = os.path.join(settings.MEDIA_ROOT, path)
#     filename = os.path.basename(fl_path)
#     if os.path.exists(fl_path):
#         fl = open(fl_path, 'r')
#         mime_type, _ = mimetypes.guess_type(fl_path)
#         response = HttpResponse(fl, content_type=mime_type)
#         response['Content-Disposition'] = "attachment; filename=%s" % filename
#         return response
