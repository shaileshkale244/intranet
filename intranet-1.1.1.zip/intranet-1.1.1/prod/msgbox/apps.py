from django.apps import AppConfig


class MsgboxConfig(AppConfig):
    name = 'msgbox'
