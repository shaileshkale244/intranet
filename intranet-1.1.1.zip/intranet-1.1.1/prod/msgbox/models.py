from django.db import models
from django.contrib.auth.models import User
from datetime import datetime


# Create your models here.
# class User(models.Model):
#     username = models.CharField(max_length=50)
#     password = models.CharField(max_length=50)
#
#     def __str__(self):
#         return self.username


class Post(models.Model):
    user = models.ForeignKey(User, db_column="user",  on_delete=models.CASCADE)
    title = models.CharField(max_length=200)
    file_field = models.FileField(upload_to='media/', blank=True)
    desc = models.TextField(blank=True)
    receiver = models.CharField(max_length=200)
    date = models.DateTimeField(default=datetime.now)

    def __str__(self):
        return f'{self.user}=> {self.title}'

#
# class UserLog(models.Model):
#     sender = models.CharField(max_length=50)
#     receiver = models.CharField(max_length=50)
#     date = models.DateTimeField(default=datetime.now)
#     file = models.FileField(upload_to='uploads/')
