# intranet
 first commit for the intranet project ,
 a basic structure of the project is commited here.
This file is for providing introduction about the intranet project.



Here the prod folder contains the required files and application folders of the django framework and intranet webapp.
